package com.example.bttuantuan6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Sanpham> arrayList;
    Adapter adapter;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listView = (ListView) findViewById(R.id.listviewsp);
        arrayList = new ArrayList<>();
        arrayList.add(new Sanpham( "Iphone 14","Giá :24.000.000",R.drawable.ip14));
        arrayList.add(new Sanpham( "Iphone 14 plus","Giá : 28.000.000",R.drawable.ip14p));
        arrayList.add(new Sanpham( "Iphone 14 Pro Max","Giá: 41.000.000",R.drawable.ip14m));

        adapter = new Adapter( MainActivity.this,R.layout.layout_listview, arrayList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this,MainActivity2.class);
                    startActivity(intent);
                }
                if(position==1){
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this,MainActivity3.class);
                    startActivity(intent);
                }
                if(position==2){
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this,MainActivity4.class);
                    startActivity(intent);
                }
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {

                deleteData(position);
                return false;
            }
        });
    }
    private void deleteData(int position){
        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Delete")
                .setMessage("Bạn có muốn xóa k?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        arrayList.remove(position);
                        adapter.notifyDataSetChanged();
                    }
                }).setNegativeButton("Cancel",null)
                .show();

    }
}