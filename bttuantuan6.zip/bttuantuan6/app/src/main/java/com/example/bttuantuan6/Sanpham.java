package com.example.bttuantuan6;


public class Sanpham {
    private String tenSP;
    private String mota;
    private int hinh;

    public Sanpham(String tenSP, String mota, int hinh) {
        this.tenSP = tenSP;
        this.mota = mota;
        this.hinh = hinh;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public int getHinh() {
        return hinh;
    }

    public void setHinh(int hinh) {
        this.hinh = hinh;
    }
}
